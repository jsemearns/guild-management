RANKS = ['Guild Master', 'Gen', 'LGen', 'MGen', 'BGen']
PERMISSIONS = [
    'Invite player',
    'Update member application',
    'Kick or Ban member',
    'Assign member rank',
]